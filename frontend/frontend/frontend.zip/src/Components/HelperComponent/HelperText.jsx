
export const ShiftHour=()=>{

    return ("The hour must be in 24-hour format, for example: You should enter 10:00 and 19:00 if your shift begins at 10 am and finishes at 7 am, respectively.")
} 

export const TeamName=()=>{

    return ("Enter company name in Company e.g: 1. AHLI Bank ESB Team  2. Mashreq Bank BPM")
} 

export const band=()=>{
    let arr1=[
        {"id":"1",band1:"Band 1"},
        {"id":"2",band1:"Band 2"},
        {"id":"3",band1:"Band 3"},
        {"id":"4",band1:"Band 4"},
        {"id":"5",band1:"Band 5"},
        {"id":"6",band1:"Band 6"},
        {"id":"7",band1:"Band 7"},
        {"id":"8",band1:"Band 8"},

    ]
    return arr1
}