
export const SerchingComponetsstyle={
    firstBox:{ height:'auto',width: 'auto'},

    SecondBox:{ display: 'flex',alignContent: 'center',justifyContent: 'space-between',marginRight:"1px"},

    typographystyle:{marginLeft:"15px",fontSize:"24px",marginTop:"20px",color:"#2196F3",fontFamily:"Times New Roman Times"},

    backbuttonstyle:{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"15px",marginRight:"12px",height:"37px"},

    Thirdbox:{height:"70px",display:"flex",width:"auto",marginLeft:"10px"},

    gridContainerStyle:{ display: 'flex',justifyContent: 'space-between',width:"100vw",marginTop:"7px"},

    griditemstyle:{  display: 'flex',justifyContent: 'center',width: 300,minWidth:"90px"},

    FormControlstyle:{width: 300 ,minWidth:"90px"},

    searchbuttonstyle:{justifyContent:"center",display:"flex",width:"250px",minWidth:"90px",height:'55px',marginRight:"10px"},

    DatagridBoxStyle:{height:"64.6vh",width:"98.7%",marginLeft:"10px",marginTop:"10px"},

    textFieldStyle:{width: 300,minWidth:"90px"}


}
