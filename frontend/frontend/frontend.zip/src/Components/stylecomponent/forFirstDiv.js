
export const GlobalStyle1={
    height:"100vh",backgroundColor:"#2196F3",width:"100vw",display:"flex"
    
}