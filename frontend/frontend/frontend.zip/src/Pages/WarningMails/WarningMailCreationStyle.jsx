



// ,backgroundColor:"#bbdefb"
export const WarningmailCreationStyle={

    firstbox:{backgroundColor:"#FFFFFF",height:"92vh",width:"100%"},
    SecondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
    typographyStyle:{color:"#2196F3",marginLeft:"10px",fontSize:"21px",marginTop:"20px",fontFamily:"Times New Roman Times"},
    
    thirdBoxStyle:{marginTop:"10px" ,boxShadow:0,width:"100%",display:'flex',justifyContent:"center",alignContent:"center"},

    gridContainerStyle:{display:"flex"},
    gridItemStyle:{display:'flex',justifyContent:'center', alignItems:'center',marginTop:"15px"},
    textFieldStyle:{width: 350,display:"flex"},
    DropzoneStyle:{border:"2px fade grey",width:"350px"},
    textFieldStyleForDescription:{width: 500,display:"flex"},

    DropZoneBoxStyle:{display:"flex",justifyContent:"space-between"}

}

export const WarningMailModalOpenStyle={

    CardStyle:{maxWidth: "500px", padding: "4px 2px", margin: "0 auto" ,marginTop:"55px"},
    secondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
    TypographyStyle:{fontSize:"25px",marginBottom:"2px",color:"#2196F3",fontFamily:"Abril Fatface",fontWeight:"bold"},
    gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center",padding:"5px"},
    thirdBoxStyle:{ marginTop:"15px"},
    typographyStyle1:{fontFamily:"Abril Fatface",fontWeight:"bold",color:"#2196F3",fontSize:"18px"},
    typography2:{fontFamily:"Source Sans Pro",fontSize:"17.5px"},
    }