
export const EmployeeSkillReportStyle={

firstBox:{backgroundColor:"#FFFFFF",height:"92vh"},
secondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
TypographyStyle:{marginLeft:"10px",fontSize:"21px",marginTop:"20px",color:"#2196F3",fontFamily:"Times New Roman Times, serif"},
backButtonStyle:{fontWeight:"bold",color:"#2196F3",marginTop:"15px",marginRight:"5px"},
gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
textFieldStyle:{width:350},
formcontrolStyle:{display:'flex',width:350},
thirdBoxStyle:{ marginTop:"15px"}


}

export const EmployeeSkillUpdateModalStyle={

    FirstBox:{ maxWidth: 370, padding: "13px 5px", margin: "0 auto" ,marginTop:"55px",backgroundColor:"#FFF"},
    secondBox:{display:"flex",justifyContent:"center",alignContent:"center"},
    TypographyStyle:{fontSize:"25px",marginBottom:"10px",color:"#2196F3"},
    gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    textFieldStyle:{width:350},
    formcontrolStyle:{display:'flex',width:350},
    thirdBoxStyle:{ marginTop:"15px"}
    
    }