

export const TerminatedEmployeeFormStyle={
    CardStyle:{ maxWidth: 350, padding: "13px 5px", margin: "0 auto" ,marginTop:"55px"},
    secondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
    TypographyStyle:{fontSize:"25px",marginBottom:"10px",color:"#2196F3",fontFamily:"Times New Roman Times"},
    gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    textFieldStyle:{width:350},
    formcontrolStyle:{display:'flex',width:400},
    thirdBoxStyle:{ marginTop:"15px"}

}
export const TerminationTableStyle={
    firstBox:{ height:'auto',width: 'auto'},

    SecondBox:{ display: 'flex',alignContent: 'center',justifyContent: 'space-between',marginRight:"1px"},

    typographystyle:{marginLeft:"15px",fontSize:"24px",marginTop:"20px",color:"#2196F3",fontFamily:"Times New Roman Times"},

    backbuttonstyle:{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"15px",marginRight:"12px",height:"37px"},


    DatagridBoxStyle:{height:"70vh",width:"98.7%",marginLeft:"10px",marginTop:"10px"},



}