export const MissingReportStyle={
       CardStyle:{ maxWidth: 400, padding: "13px 5px", margin: "0 auto" ,marginTop:"150px"},
        TypographyStyle:{fontSize:"25px",color:"#2196F3",fontFamily:"Times New Roman Times"},
        gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
        gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
        textFieldStyle:{width:170,display:"flex"},
        thirdBoxStyle:{ marginTop:"15px"}
}