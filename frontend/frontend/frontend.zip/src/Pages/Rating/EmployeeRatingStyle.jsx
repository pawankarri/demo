export const EmployeeRatingCreationStyle={

    firstBox:{backgroundColor:"#FFFFFF",height:"92vh"},
    secondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
    TypographyStyle:{marginLeft:"10px",fontSize:"21px",marginTop:"20px",color:"#2196F3",fontFamily:"Times New Roman Times"},
    gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    textFieldStyle:{width:350},
    FormControlstyle:{width:350,display:"flex"},
    RatingContainFormControlBoxStyle:{width:350,display:"flex"},
    TextFieldOfRatingBoxStyle:{display:'flex',width:165,marginLeft:"10px"},
    FormControlOfRatingBoxStyle:{display:"flex",width: 165 },
    thirdBoxStyle:{ marginTop:"15px"}
    }

    export const EmployeeReviewRatinglUpdateModalStyle={

        FirstBox:{ maxWidth: 400, padding: "13px 5px", margin: "0 auto" ,marginTop:"55px",backgroundColor:"#FFF"},
        secondBox:{display:"flex",justifyContent:"center",alignContent:"center"},
        TypographyStyle:{marginLeft:"10px",fontSize:"21px",marginTop:"20px",color:"#2196F3",fontFamily:"Times New Roman Times"},
        gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
        gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
        textFieldStyle:{width:350},
        formcontrolStyle:{display:'flex',width:350},
        thirdBoxStyle:{ marginTop:"15px"},
        RatingContainFormControlBoxStyle:{width:350,display:"flex"},
        TextFieldOfRatingBoxStyle:{display:'flex',width:165,marginLeft:"10px"},
        FormControlOfRatingBoxStyle:{display:"flex",width: 165 },
        
        }