
export const LeaveDataCreationStyle={

    firstbox:{backgroundColor:"#FFFFFF",height:"92vh",width:"100%"},
    CardStyle:{ maxWidth: 350, padding: "13px 5px", margin: "0 auto" ,marginTop:"55px"},
    SecondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
    typographyStyle:{color:"#2196F3",marginLeft:"10px",fontSize:"21px",marginTop:"20px",fontFamily:"Times New Roman Times"},
    thirdBoxStyle:{marginTop:"10px" ,boxShadow:0,width:"100%",display:'flex',justifyContent:"center",alignContent:"center"},
    backbuttonstyle:{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"15px",marginRight:"12px",height:"35px"},
    gridContainerStyle:{display:"flex"},
    gridItemStyle:{display:'flex',justifyContent:'center', alignItems:'center',marginTop:"15px"},
    textFieldStyle:{width: 350,display:"flex"},
    FormControlstyle:{width:350,display:"flex"},

}


export const LeavesComponetsstyle={
    firstBox:{ height:'auto',width: 'auto'},

    SecondBox:{ display: 'flex',alignContent: 'center',justifyContent: 'space-between',marginRight:"1px"},
    ThirdBox:{ display: 'flex',alignContent: 'center',justifyContent: 'flex-end',marginRight:"1px"},

    typographystyle:{marginLeft:"15px",fontSize:"24px",marginTop:"20px",color:"#2196F3",fontFamily:"Times New Roman Times"},

    backbuttonstyle:{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"15px",marginRight:"12px",height:"40px"},

    gridContainerStyle:{ display: 'flex',justifyContent: 'space-between',width:"100vw",marginTop:"7px"},

    griditemstyle:{  display: 'flex',justifyContent: 'center',width: 300,minWidth:"90px"},
    DatagridBoxStyle:{height:"64.6vh",width:"98.7%",marginLeft:"10px",marginTop:"10px"},



}