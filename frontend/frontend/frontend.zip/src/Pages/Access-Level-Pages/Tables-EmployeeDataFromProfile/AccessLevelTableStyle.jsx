export const AccessLevelTableStyle={
    firstBox:{ height:'auto',width: 'auto'},

    SecondBox:{ display: 'flex',alignContent: 'center',justifyContent: 'space-between',marginRight:"1px"},

    typographystyle:{marginLeft:"15px",fontSize:"24px",marginTop:"20px",color:"#2196F3",fontFamily:"Times New Roman Times"},

    backbuttonstyle:{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"15px",marginRight:"12px",height:"37px"},


    DatagridBoxStyle:{height:"70vh",width:"98.7%",marginLeft:"10px",marginTop:"10px"},
    thirdbox:{display:"flex",justifyContent:"flex-end"}

}
