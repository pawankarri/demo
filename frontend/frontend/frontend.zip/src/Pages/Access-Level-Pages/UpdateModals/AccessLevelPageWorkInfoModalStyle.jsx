export const AccessLevelWorkInfoModalStyle={

    CardStyle:{ maxWidth: 350, padding: "13px 5px", margin: "0 auto" ,marginTop:"55px"},
    secondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
    TypographyStyle:{fontSize:"25px",marginBottom:"10px",color:"#2196F3",fontFamily:"Times New Roman Times"},
    gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
    textFieldStyle:{width:350},
    formcontrolStyle:{display:'flex',width:400},
    thirdBoxStyle:{ marginTop:"15px"}
    
    }

    export const AccessLevelContactModalStyle={

        CardStyle:{ maxWidth: 400, padding: "13px 5px", margin: "0 auto" ,marginTop:"150px"},
        TypographyStyle:{fontSize:"25px",color:"#2196F3",fontFamily:"Times New Roman Times"},
        gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
        gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
        textFieldStyle:{width:350},
        thirdBoxStyle:{ marginTop:"15px"}
        
        }  


export const AccessLevelShiftTimingModalPagesStyle={

            CardStyle:{maxWidth:350, padding: "10px 5px", margin: "0 auto",marginTop:"12px"},
            secondBox:{display:"flex",justifyContent:"space-between",alignContent:"center"},
            TypographyStyle:{fontSize:"25px",color:"#2196F3",fontFamily:"Times New Roman Times"},
            gridContinerStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
            gridItemStyle:{display:"flex",justifyContent:"center",alignContent:"center"},
            textFieldStyle:{width:340},
            shiftStartAndEndBoxStyle:{width:340},
            TextFieldOfShiftStartAndEndBoxStyle:{display:'flex',width:165},
            FormControlOfShiftStartAndEndBoxStyle:{width: 165,marginLeft:"10px" },
            thirdBoxStyle:{ marginTop:"15px"}
    }
        
              